package dev.legacy.shizzi;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private TextView status, log;
    private String runRoot(String script) throws Exception {
        Process p = new ProcessBuilder("su", "-c", "sh").redirectErrorStream(true).start();
        try (OutputStream os = p.getOutputStream()) {
            os.write((script + "\nexit\n").getBytes("UTF-8")); os.flush();
        }
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line; while ((line = r.readLine()) != null) out.append(line).append('\n');
        }
        int code = p.waitFor();
        return "exit=" + code + "\n" + out;
    }
    private String asset(String name) throws Exception {
        InputStream in = getAssets().open(name); byte[] b = new byte[in.available()]; int n=in.read(b); in.close();
        return new String(b, 0, n, "UTF-8");
    }
    private void action(String file) {
        status.setText("Running root command…");
        new Thread(() -> {
            try {
                String result = runRoot(asset(file));
                runOnUiThread(() -> { log.setText(result); status.setText(result.contains("exit=0") ? "Command completed" : "Command failed — see log"); });
            } catch (Exception e) {
                runOnUiThread(() -> { status.setText("Root error"); log.setText(e.toString()); });
            }
        }).start();
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,32,28,24);
        TextView title = new TextView(this); title.setText("Shizzi Legacy"); title.setTextSize(28); title.setTypeface(null, Typeface.BOLD);
        TextView desc = new TextView(this); desc.setText("Android 10 • Magisk Root • Experimental IPv4 TTL helper\nTurn on the phone hotspot or USB tethering first."); desc.setTextSize(14); desc.setPadding(0,12,0,18);
        status = new TextView(this); status.setText("Waiting for action"); status.setTextSize(16); status.setPadding(0,8,0,12);
        Button start = new Button(this); start.setText("Enable compatibility rules"); start.setOnClickListener(v -> action("enable.sh"));
        Button stop = new Button(this); stop.setText("Disable / remove rules"); stop.setOnClickListener(v -> action("disable.sh"));
        TextView logTitle = new TextView(this); logTitle.setText("ROOT LOG"); logTitle.setTypeface(null, Typeface.BOLD); logTitle.setPadding(0,18,0,8);
        log = new TextView(this); log.setTextIsSelectable(true); log.setTextSize(12); log.setText("No commands run yet.");
        root.addView(title); root.addView(desc); root.addView(status); root.addView(start); root.addView(stop); root.addView(logTitle); root.addView(log);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
    }
}

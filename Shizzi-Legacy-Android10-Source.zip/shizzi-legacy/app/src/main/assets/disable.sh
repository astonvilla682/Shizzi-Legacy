#!/system/bin/sh
set +e
IPT="$(command -v iptables || true)"
[ -n "$IPT" ] || IPT=/system/bin/iptables
MARK='0x5348'
for IF in 'wlan+' 'ap+' 'rndis+' 'usb+'; do
  "$IPT" -t mangle -D PREROUTING -i "$IF" -j MARK --set-mark "$MARK" 2>/dev/null
done
for UP in $(ip -4 route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | sort -u); do
  "$IPT" -t mangle -D POSTROUTING -o "$UP" -m mark --mark "$MARK" -j TTL --ttl-set 64 2>/dev/null
done
echo 'Removed Shizzi Legacy rules where found.'

#!/system/bin/sh
# Experimental TTL-based tethering compatibility helper for rooted Android 10.
# It does NOT implement Shizzi's TestNetwork/TUN datapath.
set -eu
TAG='SHIZZILEGACY'
MARK='0x5348'
IPT="$(command -v iptables || true)"
[ -n "$IPT" ] || IPT=/system/bin/iptables
[ -x "$IPT" ] || { echo 'iptables not found'; exit 2; }
"$IPT" -t mangle -L >/dev/null 2>&1 || { echo 'iptables mangle table unavailable'; exit 3; }
UP="$(ip -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n1)"
[ -n "$UP" ] || { echo 'Cannot detect mobile-data upstream interface'; exit 4; }
# Remove only our own old rules before applying.
"$IPT" -t mangle -D PREROUTING -i wlan+ -j MARK --set-mark "$MARK" 2>/dev/null || true
"$IPT" -t mangle -D PREROUTING -i ap+ -j MARK --set-mark "$MARK" 2>/dev/null || true
"$IPT" -t mangle -D PREROUTING -i rndis+ -j MARK --set-mark "$MARK" 2>/dev/null || true
"$IPT" -t mangle -D PREROUTING -i usb+ -j MARK --set-mark "$MARK" 2>/dev/null || true
"$IPT" -t mangle -D POSTROUTING -o "$UP" -m mark --mark "$MARK" -j TTL --ttl-set 64 2>/dev/null || true
"$IPT" -t mangle -A PREROUTING -i wlan+ -j MARK --set-mark "$MARK"
"$IPT" -t mangle -A PREROUTING -i ap+ -j MARK --set-mark "$MARK"
"$IPT" -t mangle -A PREROUTING -i rndis+ -j MARK --set-mark "$MARK"
"$IPT" -t mangle -A PREROUTING -i usb+ -j MARK --set-mark "$MARK"
"$IPT" -t mangle -A POSTROUTING -o "$UP" -m mark --mark "$MARK" -j TTL --ttl-set 64 || { echo 'TTL target unavailable in this kernel'; exit 5; }
echo "Enabled IPv4 TTL adjustment; upstream=$UP. This is not a full Shizzi tunnel."

# Shizzi Legacy (experimental)

An original, open-source Android 10 / rooted-device experiment. It is **not** a port of Shizzi 0.6.0 and does not reproduce Shizzi's TestNetwork + Go TUN datapath.

## What it does

The app asks Magisk for root and applies/removes a narrowly marked IPv4 TTL mangle rule for common Wi-Fi AP / USB tethering interface names. This can help only with carrier tethering detection methods that rely on the IPv4 TTL hop count. It does **not** defeat account-side tethering entitlement, APN restrictions, carrier policy checks, or data-plan limits. It does not implement IPv6 hop-limit handling, VPN forwarding, DNS interception, a tunnel, or guarantee that MIUI's interface names match the patterns.

## Target

- Xiaomi Mi 9 (ARM64)
- Android 10 / API 29
- MIUI 12.5
- Magisk root

## Build

Requires JDK 17+, Android SDK Platform 35, Android Build Tools, and Gradle 8.7+.

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Use

1. Install the APK and grant the Magisk superuser prompt.
2. Enable the phone's Wi-Fi hotspot or USB tethering.
3. Tap **Enable compatibility rules**.
4. Test with one connected device. If it does not work, use **Disable / remove rules** and inspect the log.

The rules are not persistent across reboot. The app does not automatically alter APN or carrier configuration.

## Safety

Root firewall changes can disrupt connectivity. The disable button removes rules carrying mark `0x5348`; reboot also clears these non-persistent rules on stock configurations. Use at your own risk.

## License

MIT License. Copyright (c) 2026 Shizzi Legacy contributors.
